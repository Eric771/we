from base import _bot
_bot(st='ue65779e39ef3f06c97948ed961570887:aWF0OiA5NzU3NDM0Nzc0MAo=..2zlSShTpJlH0mzWy/bkBm+gHCVc=')