#======================================================================#
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#                  Copyright © 2018-2021 幻想 版權所有                  #
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#======================================================================#
from linepy import LINE,OEPoll
import socket,json,threading,os
port,byte=8102,2048
host='108.61.162.113'
def auth(email=None,password=None,authtoken=None,st=None):
    try:
        if email and not password:raise Exception('請輸入密碼')
        if password and not email:raise Exception('請輸入帳號')
        if not email and not password and not authtoken and not st:raise Exception('請給予權杖或帳密')
        if st:tmp=LINE(st,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.11.1')
        if authtoken:tmp=LINE(authtoken)
        # js=json.loads(open('txt/token','r').read())
        # if email in js:tmp=LINE(js[email])
        if email and password:
            print(f'email:{email}\npassword:{password}')
            tmp=LINE(email,password)
        #js[email]=tmp.authToken
        #open('txt/token','w').write(str(js))
        isSt=False
        if st:isSt=True
        return tmp,isSt
    except AttributeError:
        print('尚未輸入驗證碼\n系統將退出')
        os._exit(1)
    except Exception as e:
        if e.code==35:
            js=json.loads(open('txt/token','r').read())
            if email in js:
                del js[email]
                open('txt/token','w').write(str(js))
            raise Exception('此帳號已禁言')
        elif e.code==18:
            js=json.loads(open('txt/token','r').read())
            if email in js:
                del js[email]
                open('txt/token','w').write(str(js))
            raise Exception('帳密錯誤(或不存在)')
        else:raise Exception(e)
class _host:
    def __init__(self,email=None,password=None,authtoken=None,st=None):
        self.bot,self.isSt=auth(email,password,authtoken,st)
        self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','主機 登入成功')
        self.oepoll=None
        self.tokens=[]
        self.isConnect={}
        self.socketObj={}
        self.bots=[]
        self.botnum=0
        threading.Thread(target=self.startbot,args=(self.bot,)).start()
        self._HostSocket(port)
    def loadToken(self,token):return self.tokens.append(LINE(token))
    def bot_(self,op):
        try:
            if op.type in [0]:return
            if op.type == 5:self.bot.findAndAddContactsByMid(op.param1)
            if op.type in [13,124]:
                self.bot.acceptGroupInvitation(op.param1)
                self.bot.sendMessage(op.param1,'歡迎使用幻想戰爭單體防禦!(開發中)')
                if self.bots != []:
                    self.bot.inviteIntoGroup(op.param1,self.bots)
            if op.type == 26:
                msg      =   op.message
                text     =   msg.text
                msg_id   =   msg.id
                receiver =   msg.to
                sender   =   msg._from
                if msg.toType == 0:
                    if sender != self.bytbot.profile.mid:to = sender
                    else:to = receiver
                else:to     = receiver
                try:text.lower()
                except:return
                if sender == 'uac96e80c8ab42621be4a7b7558f5b258':
                    if text=='報數':
                        self.bot.sendMessage(to,'我是主機')
                        ips=[x for x in self.socketObj]
                        for x in ips:
                            msg=f"""exec:if self.team == 'bot':mg='我是分機'
if self.team == 'js':mg='我是JS'
if self.team == 'url':mg='我是網址'
self.bot.sendMessage('{to}',mg)"""
                            self.socketObj[str(x)].send(msg.encode())
                    if text.lower()=='bot:bye':
                        if msg.toType == 2:
                            self.bot.leaveGroup(to)
        except Exception as e:print(str(e))
    def loadToken(self,token=None):
        def load(token):
            if not self.isSt:
                self.tokens.append(LINE(token))
            if self.isSt:
                self.tokens.append(LINE(token,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.11.1'))
        task=[]
        for x in range(1000):
            t=threading.Thread(target=load,args=(token,))
            task.append(t)
        for x in task:x.start()
        for x in task:x.join()
        return True
    def startbot(self,client=None):
        print('正在載入線呈...')
        self.loadToken(client.authToken)
        print('載入線呈完成!')
        self.oepoll=OEPoll(client)
        while 1:
            ops=self.oepoll.singleTrace(count=1000)
            if ops:
                for x in ops:
                    threading.Thread(target=self.bot_,args=(x,)).start()
                    self.oepoll.setRevision(x.revision)
    def _HostSocket(self,port:None):
        s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
        s.connect(('8.8.8.8',80))
        ip=s.getsockname()[0]
        self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258',f'IP:{ip}\n 等待連接中...')
        print(f'IP:{ip}\n等待連接中...')
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        s.bind((ip,port))
        self._HostConnect(s)
    def _processRequests(self,conn=None,addr=None):
        self.socketObj[addr[0]]=conn
        print(addr[0]+'加入連線。')
        self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258',f'{addr[0]} 加入連線。')
        self.isConnect[addr[0]]=True
        while self.isConnect[addr[0]]:
            try:
                rec=conn.recv(byte)
                print(addr[0]+' > '+rec.decode())
                if len(rec) == 0:
                    del self.isConnect[addr[0]]
                    return
                command=rec.decode()
                if command=='syncjson':
                    conn.send(open('json/settings.json','r').read().encode())
                elif command=='getnum':
                    self.botnum+=1
                    conn.send(str(self.botnum).encode())
                elif command.startswith('mid:'):
                    mid=command[4:]
                    self.bots.append(mid)
                    #conn.send(f'mid:{self.bot.profile.mid}'.encode())
                    self.bot.findAndAddContactsByMid(mid)
                elif command.startswith('sendmsg:'):
                    spl=command.split(':')
                    mid=spl[1]
                    msg=command[len(spl[0])+len(spl[1]):]
                    conn.send(f'mid:{mid}\nmsg:{msg}'.encode())
                elif command.startswith('exception:'):
                    spl=command.split(':')
                    self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258',f'[ 錯誤 ]\n位置:{spl[1]}\n發生以下錯誤:\n{spl[2]}')
                else:
                    conn.send('無效的指令值'.encode())
            except Exception as e:
                self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258',f'[ Socket錯誤 ]\nIP:{addr[0]}\n連線時發生不明錯誤\n內容如下:\n{e}\n請至後台查看。')
    def _HostConnect(self,obj=None):
        while 1:
            obj.listen()
            conn,addr=obj.accept()
            threading.Thread(target=self._processRequests,args=(conn,addr)).start()
class _bot:
    def __init__(self,email=None,password=None,authtoken=None,st=None):
        self.bot,self.isSt=auth(email,password,authtoken,st)
        self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','分機 登入成功')
        self.isConnect=False
        self.bots=[]
        self.team='bot'
        self.tokens=[]
        self.socket=None
        self.botnumber=None
        threading.Thread(target=self.startbot,args=(self.bot,)).start()
        self._ConnectSocket(port)
    def loadToken(self,token):return self.tokens.append(LINE(token))
    def loadToken(self,token=None):
        def load(token):
            if not self.isSt:
                self.tokens.append(LINE(token))
            if self.isSt:
                self.tokens.append(LINE(token,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.11.1'))
        task=[]
        for x in range(1000):
            t=threading.Thread(target=load,args=(token,))
            task.append(t)
        for x in task:x.start()
        for x in task:x.join()
        return True
    def startbot(self,client=None):
        print('正在載入線呈...')
        self.loadToken(client.authToken)
        print('載入線呈完成!')
        self.oepoll=OEPoll(client)
        while 1:
            ops=self.oepoll.singleTrace(count=1000)
            if ops:
                for x in ops:
                    threading.Thread(target=self.bot_,args=(x,)).start()
                    self.oepoll.setRevision(x.revision)
    def _ConnectSocket(self,port:None):
        try:
            s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            s.connect((host,port))
            s.send('syncjson'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            self.bots=json.loads(rec.decode())['bots']
            s.send('getnum'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            s.send(f'mid:{self.bot.profile.mid}'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            self.botnumber=rec.decode()
            self.socket=s
            while 1:
                rec=s.recv(byte)
                print(rec.decode())
                cmd=rec.decode()
                if len(rec)==0:
                    print(f'[ 錯誤 ]\n分機{self.botnumber if self.botnumber != None else ""}與主機 Socket中斷連線。')
                    self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258',f'[ 錯誤 ]\n分機{self.botnumber if self.botnumber != None else ""}與主機 Socket中斷連線。')
                    os._exit(1)
                if cmd.startswith('exec:'):
                    print('檢測到exec')
                    try:exec(cmd[5:])
                    except Exception as e:
                        s.send(f'exception:Bot{self.botnumber}:{e}'.encode())
        except:
            self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258',f'[ 錯誤 ]\n分機{self.botnumber if self.botnumber != None else ""} Socket 連線失敗\n請至伺服器後台查看。')
    def bot_(self,op):
        try:
            if op.type in [0]:return
            if op.type in [13,124]:
                self.bot.acceptGroupInvitation(op.param1)
            if op.type == 26:
                msg      =   op.message
                text     =   msg.text
                msg_id   =   msg.id
                receiver =   msg.to
                sender   =   msg._from
                if msg.toType == 0:
                    if sender != self.bytbot.profile.mid:to = sender
                    else:to = receiver
                else:to     = receiver
                try:text.lower()
                except:return
                if sender == 'uac96e80c8ab42621be4a7b7558f5b258':
                    if text.lower()=='bot:bye':
                        if msg.toType == 2:
                            self.bot.leaveGroup(to)
        except Exception as e:print(str(e))
class _js:
    def __init__(self,email=None,password=None,authtoken=None,st=None):
        self.bot,self.isSt=auth(email,password,authtoken,st)
        self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','Js 登入成功')
        self.isConnect=False
        self.bots=[]
        self.team='js'
        self.tokens=[]
        self.socket=None
        threading.Thread(target=self.startbot,args=(self.bot,)).start()
        self._ConnectSocket(port)
    def loadToken(self,token=None):
        def load(token):
            if not self.isSt:
                self.tokens.append(LINE(token))
            if self.isSt:
                self.tokens.append(LINE(token,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.11.1'))
        task=[]
        for x in range(1000):
            t=threading.Thread(target=load,args=(token,))
            task.append(t)
        for x in task:x.start()
        for x in task:x.join()
        return True
    def startbot(self,client=None):
        print('正在載入線呈...')
        self.loadToken(client.authToken)
        print('載入線呈完成!')
        self.oepoll=OEPoll(client)
        while 1:
            ops=self.oepoll.singleTrace(count=1000)
            if ops:
                for x in ops:
                    threading.Thread(target=self.bot_,args=(x,)).start()
                    self.oepoll.setRevision(x.revision)
    def _ConnectSocket(self,port:None):
        try:
            s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            s.connect((host,port))
            s.send('syncjson'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            s.send(f'mid:{self.bot.profile.mid}'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            self.bots=json.loads(rec.decode())['bots']
            self.socket=s
            while 1:
                rec=s.recv(byte)
                print(rec.decode())
                cmd=rec.decode()
                if len(rec)==0:
                    print('[ 錯誤 ]\nJs與主機 Socket中斷連線。')
                    self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','[ 錯誤 ]\nJs與主機 Socket中斷連線。')
                    os._exit(1)
                if cmd.startswith('exec:'):
                    try:exec(cmd[5:])
                    except Exception as e:
                        s.send(f'exception:Js:{e}'.encode())
        except:
            self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','[ 錯誤 ]\nJs Socket 連線失敗\n請至伺服器後台查看。')
    def bot_(self,op):
        try:
            if op.type in [0]:return
            if op.type in [13,124]:
                self.bot.acceptGroupInvitation(op.param1)
            if op.type == 26:
                msg      =   op.message
                text     =   msg.text
                msg_id   =   msg.id
                receiver =   msg.to
                sender   =   msg._from
                if msg.toType == 0:
                    if sender != self.bytbot.profile.mid:to = sender
                    else:to = receiver
                else:to     = receiver
                try:text.lower()
                except:return
                if sender == 'uac96e80c8ab42621be4a7b7558f5b258':
                    if text.lower()=='bot:bye':
                        if msg.toType == 2:
                            self.bot.leaveGroup(to)
        except Exception as e:print(str(e))
class _url:
    def __init__(self,email=None,password=None,authtoken=None,st=None):
        self.bot,self.isSt=auth(email,password,authtoken,st)
        self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','Url 登入成功')
        self.isConnect=False
        self.bots=[]
        self.team='url'
        self.tokens=[]
        self.socket=None
        threading.Thread(target=self.startbot,args=(self.bot,)).start()
        self._ConnectSocket(port)
    def loadToken(self,token=None):
        def load(token):
            if not self.isSt:
                self.tokens.append(LINE(token))
            if self.isSt:
                self.tokens.append(LINE(token,appName='ANDROIDLITE\t2.16.0\tAndroid OS\t11.11.1'))
        task=[]
        for x in range(1000):
            t=threading.Thread(target=load,args=(token,))
            task.append(t)
        for x in task:x.start()
        for x in task:x.join()
        return True
    def startbot(self,client=None):
        print('正在載入線呈...')
        self.loadToken(client.authToken)
        print('載入線呈完成!')
        self.oepoll=OEPoll(client)
        while 1:
            ops=self.oepoll.singleTrace(count=1000)
            if ops:
                for x in ops:
                    threading.Thread(target=self.bot_,args=(x,)).start()
                    self.oepoll.setRevision(x.revision)
    def _ConnectSocket(self,port:None):
        try:
            s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            s.connect((host,port))
            s.send('syncjson'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            s.send(f'mid:{self.bot.profile.mid}'.encode())
            rec=s.recv(byte)
            print(rec.decode())
            self.bots=json.loads(rec.decode())['bots']
            self.socket=s
            while 1:
                rec=s.recv(byte)
                print(rec.decode())
                cmd=rec.decode()
                if len(rec)==0:
                    print('[ 錯誤 ]\nUrl Socket中斷連線。')
                    self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','[ 錯誤 ]\nUrl Socket中斷連線。')
                    os._exit(1)
                if cmd.startswith('exec:'):
                    try:exec(cmd[5:])
                    except Exception as e:
                        s.send(f'exception:Url:{e}'.encode())
        except:
            self.bot.sendMessage('uac96e80c8ab42621be4a7b7558f5b258','[ 錯誤 ]\nUrl Socket 連線失敗\n請至伺服器後台查看。')
    def bot_(self,op):
        try:
            if op.type in [0]:return
            if op.type in [13,124]:
                self.bot.acceptGroupInvitation(op.param1)
            if op.type == 26:
                msg      =   op.message
                text     =   msg.text
                msg_id   =   msg.id
                receiver =   msg.to
                sender   =   msg._from
                if msg.toType == 0:
                    if sender != self.bot.profile.mid:to = sender
                    else:to = receiver
                else:to     = receiver
                try:text.lower()
                except:return
                if sender == 'uac96e80c8ab42621be4a7b7558f5b258':
                    if text.lower()=='bot:bye':
                        if msg.toType == 2:
                            self.bot.leaveGroup(to)
        except Exception as e:print(str(e))
#======================================================================#
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#                  Copyright © 2018-2021 幻想 版權所有                  #
#                                                                      #
#                                                                      #
#                                                                      #
#                                                                      #
#======================================================================#